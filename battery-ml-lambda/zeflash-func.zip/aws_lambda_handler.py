import os
import json
from typing import Any, Dict
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError


def _is_charging(items: list) -> bool:
    """Infer charging state from API items (status/eventtype)."""
    if not items:
        return False
    latest = items[-1] if isinstance(items[-1], dict) else items[0]
    status = (latest.get("status") or latest.get("Status") or "").lower()
    event = (latest.get("eventtype") or latest.get("eventType") or "").lower()

    keywords = ["charging", "chargingstarted", "charging_in_progress"]
    return any(k in status for k in keywords) or any(k in event for k in keywords)


def _build_cms_time_lapsed_url(evse_id: str, connector_id: int = 1, page: int = 1, limit: int = 10,
                               role: str = "Admin", operator: str = "All") -> str:
    base = "https://cms.charjkaro.in/commands/secure/api/v1/get/charger/time_lapsed"
    qs = urlencode({
        "role": role,
        "operator": operator,
        "evse_id": evse_id,
        "connector_id": connector_id,
        "page": page,
        "limit": limit,
    })
    return f"{base}?{qs}"


def _fetch_data_from_api(api_url: str, auth_token: str, timeout: int = 20) -> list:
    headers = {"Authorization": f"Basic {auth_token}"}
    req = Request(api_url, headers=headers)
    try:
        with urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except HTTPError as e:
        raise RuntimeError(f"HTTP {e.code}: {e.reason}")
    except URLError as e:
        raise RuntimeError(f"URL error: {e.reason}")

    # Normalize to list of items
    if isinstance(data, dict):
        if isinstance(data.get("data"), list):
            return data["data"]
        for v in data.values():
            if isinstance(v, list):
                return v
        return [data]
    if isinstance(data, list):
        return data
    return [data]


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """AWS Lambda entrypoint.

    Input (event):
    - evse_id: string
    - connector_id: int (1/2/3)
    - limit: int (default 10)
    - token: optional (if omitted, use env CMS_BASIC_TOKEN)

    Output:
    - charging: bool
    - action: 'reading' (no generation) or 'generated'
    - message: short UX hint
    - s3_url: optional presigned URL if generated
    - s3_key, device_id, data_points, status
    """
    # Support both direct invocation and HTTP (Function URL / API Gateway)
    qs = event.get("queryStringParameters") or {}
    evse_id = str((event.get("evse_id") or qs.get("evse_id") or "")).strip()
    connector_id = int(event.get("connector_id") or qs.get("connector_id") or 1)
    limit = int(event.get("limit") or qs.get("limit") or 10)
    token = (event.get("token") or qs.get("token") or os.environ.get("CMS_BASIC_TOKEN"))

    if not evse_id:
        return {"error": "Missing evse_id"}
    if not token:
        return {"error": "Missing token (set CMS_BASIC_TOKEN or pass event.token)"}

    api_url = _build_cms_time_lapsed_url(evse_id=evse_id, connector_id=connector_id, limit=limit)

    # Peek API to decide action
    try:
        items = _fetch_data_from_api(api_url, auth_token=token)
    except Exception as e:
        return {
            "error": f"fetch_failed: {str(e)}",
            "charging": False,
            "action": "idle",
            "message": "Could not fetch CMS data",
            "device_id": f"{evse_id}_{connector_id}",
            "data_points": 0,
        }
    charging = _is_charging(items)

    device_id = f"{evse_id}_{connector_id}"

    if charging:
        # Do not generate report; inform UI to show live reading message
        return {
            "charging": True,
            "action": "reading",
            "message": "Charging in progress — getting readings",
            "device_id": device_id,
            "data_points": len(items),
        }

    # Not charging — if we have data, try to generate the S3 report
    if items:
        try:
            # Lazy import to avoid heavy deps on cold start if unavailable
            from inference_pipeline import run_inference_pipeline  # type: ignore
            result = run_inference_pipeline(
                device_id=device_id,
                api_url=api_url,
                auth_token=token,
                limit=limit,
                auth_scheme="Basic",
            )
            return {
                "charging": False,
                "action": "generated",
                "message": "Report generated",
                "device_id": result.get("device_id"),
                "status": result.get("status"),
                "data_points": result.get("data_points"),
                "s3_key": result.get("s3_key"),
                "s3_url": result.get("s3_url"),
            }
        except Exception as e:
            return {
                "charging": False,
                "action": "idle",
                "message": f"Report generation unavailable: {str(e)}",
                "device_id": device_id,
                "data_points": len(items),
            }

    # No data and not charging — inform UI
    return {
        "charging": False,
        "action": "idle",
        "message": "No active charging and no recent data",
        "device_id": device_id,
        "data_points": 0,
    }
